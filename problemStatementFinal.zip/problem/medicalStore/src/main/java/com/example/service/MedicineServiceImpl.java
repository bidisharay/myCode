package com.example.service;

import java.util.*;
import java.util.stream.Collectors;

import com.example.entity.Medicine;
import com.example.exception.MedicineNotFoundException;
import com.example.repository.MedicineRepositoryStub;

public class MedicineServiceImpl implements MedicineService{

	MedicineRepositoryStub medicineRepository=new MedicineRepositoryStub();

	private static Double apply(Map.Entry<Integer, Medicine> m) {
		return m.getValue().price;
	}

	@Override
	public Medicine getMedicine(int id) throws MedicineNotFoundException {

		HashMap<Integer, Medicine> medicines = medicineRepository.getMedicines();
		List<Medicine> collect = medicines.entrySet().stream()
				.filter(i -> i.getValue().getId() == id).collect(Collectors.toList())
				.stream().map(Map.Entry::getValue).collect(Collectors.toList());
		if (collect.isEmpty()) {
			return null;
		} else {

			return collect.get(0);


		}


	}

	@Override
	public Boolean isAvailable(int id) throws MedicineNotFoundException {
		HashMap<Integer, Medicine> medicines = medicineRepository.getMedicines();

		List<Medicine> collect = medicines.entrySet().stream()
				.filter(i -> i.getValue().getId() == id).toList()
				.stream().map(Map.Entry::getValue).toList();
		if (collect.size() == 0) {
			return null;
		} else {
			return collect.stream().map(Medicine::isAvailability).findAny().get();
		}


	}


	@Override
	public List<String> manufacturers(String name) throws MedicineNotFoundException {
		HashMap<Integer, Medicine> medicines = medicineRepository.getMedicines();

		List<Medicine> collect = medicines.entrySet().stream()
				.filter(i -> i.getValue().getName().equals(name)).toList()
				.stream().map(Map.Entry::getValue).toList();

		List<String> collect1 = collect.stream().map(Medicine::getManufacturer).collect(Collectors.toList());
		if (collect1.size() >0){
			return collect1;
		}else {
			return null;
		}
	}

	@Override
	public String getLowestPriceByManufacturer(String medicineName) throws MedicineNotFoundException {
		// TODO Auto-generated method stub
		List<Medicine> collect ;

		HashMap<Integer, Medicine> medicines = medicineRepository.getMedicines();

		collect = medicines.entrySet().stream()
				.filter(i -> i.getValue().getName().equals(medicineName)).toList()
				.stream().map(Map.Entry::getValue).collect(Collectors.toList());

		Medicine medicine = collect.stream().min(Comparator.comparing(Medicine::getPrice)).orElse(null);

		if (medicine != null) {
			return medicine.getManufacturer();
		} else{
			return "No manufacturers found";
		}
	}

}
